#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "iic.h"  
#include "pll.h"
#include "sci1.h"

#include "l3g4200.h"  // register's definitions

 
volatile uint8_t alarmSignaled1 = 0; /* Flag set when alarm 1 signaled */

volatile uint16_t currentTime1 = 0; /* variables private to timeout routines */
uint16_t alarmTime1 = 0;
volatile uint8_t alarmSet1 = 0;

// void INTERRUPT timer6(void);

void setAlarm1(uint16_t msDelay1);
void delay1(uint16_t msDelay1);
void Init_TC6 (void);


#define BUFF_SIZE	100
char buff[BUFF_SIZE];
int gxraw[BUFF_SIZE];
int gyraw[BUFF_SIZE],gzraw[BUFF_SIZE];	


int k;


void l3g4200d_getrawdata(int *gxraw, int *gyraw, int *gzraw);
void gyro_init(void);
void gyro_test(void);


 void laser_init (void);
 void laser_data(uint16_t *Dist) ;


 uint16_t LidarWriteAddr = 0xc4;
uint16_t LidarReadAddr = 0xc5;
uint16_t Lidar2ByteRead = 0x8f;

uint16_t Dist;



void main(void) {
  /* put your own code here */
  
  char  myString[20];
 char character;
  
 uint8_t D2W, D3R, WHO, who;
 int  res1, res2,  res3, *p;
 
 

DDRB= 0xFF;   /* Port B output */
 DDRJ= 0xFF;   // Port J to Output
 PTJ = 0x00;   // enable LEDs
 
 PORTB=0x55;     // debuging info
 PLL_Init();  // make sure we are runnign at 24 Mhz

EnableInterrupts;

 SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)
  

 
 SCI1_OutString("Program Starting ");
 
 Init_TC6();

 iicinit();
 
// laser_init () ;
 
// delay1(20);    // wait for 20 msec according to manual
 
 
 
 
// gyro_test(); // make sure a l3g is connected
 
// gyro_init();     // l3g4200 setup

 
 while(1) {
  
 delay1(100); 
 
laser_data (&Dist) ;
 
//  l3g4200d_getrawdata( &gxraw, &gyraw, &gzraw) ;        // read data

// SCI1_OutUDec((unsigned short) gxraw[0]) ; 

 SCI1_OutUDec((unsigned short) Dist) ;

 SCI1_OutString("\n\r");
  
 //  PORTB=(gxraw[0]>>8) & 0x00ff;
 
// PORTB=(Dist>>8)&0x00ff   ;
 }


  
  

  for(;;) {
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}


//   ******************  END Main   *****************




// test the precense of Gyro , should get 211 on return 
// 

void gyro_test(void) {
 int res1,who; 
 
 res1=iicstart(0xD2);
 res1=iictransmit(L3G4200D_WHO_AM_I);
 
res1=iicrestart(0xD3);
who=iicreceiveone();
who=who & 0x00ff;
//PORTB=  who ;   
}



 //  Gyro Initialisation
 
 
 void gyro_init (void) {
  
 int  res1;
 
 res1=iicstart(0xD2);
 
 res1=iictransmit(L3G4200D_CTRL_REG1 );  // ; 100hz, 12.5Hz, Power up
 
 res1=iictransmit(0x0f );
 
 iicstop();  
 }
 
 
// Function to get a set of gyro data
// Eduardo Nebot,30 JUly 2015 

void l3g4200d_getrawdata(int *gxraw, int *gyraw, int *gzraw) {
 	uint8_t i = 0;
	uint8_t buff[6];
	int res1;
	
 res1=iicstart(0xD2);
 
 res1=iictransmit(L3G4200D_OUT_XYZ_CONT );
 
 res1= iicrestart(0xD3); 
 
 iicswrcv();
 
 for(i=0; i<4  ;i++) {
  buff[i]=iicreceive();
 }
 
buff[i]= iicreceivem1();
buff[i+1]= iicreceivelast();

	*gxraw = ((buff[1] << 8) | buff[0]);
	*gyraw = ((buff[3] << 8) | buff[2]);
	*gzraw = ((buff[5] << 8) | buff[4]);
}

// ********************

 // Laser  initialisation, Eduardo nebot , 2/8/15
 
       
       
 void laser_init (void) {
  
 int  res1;


 
 //k=iicstart(LidarWriteAddr);
  k=iicstart(0xc4);
 
 k=iictransmit(0x00 );  // ; write register 0x00 with value 0x04
                          // (This performs a DC stabilization cycle,
                          // Signal Acquisition, Data processing).  
                          //Refer to the section �I2C Protocol Summary
                          // in this manual for more information about
                          // I2C Communications
 
 k=iictransmit(0x04 );
 
 iicstop();  
 }
 
 
// Function to get a set of gyro data
// Eduardo Nebot,30 JUly 2015 

void laser_data(uint16_t *Dist) {

	uint8_t buff[2];
	int res1;
	
   laser_init();

 // k=iicstart(0xc4);
 
// k=iictransmit(0x00 );  // ; write register 0x00 with value 0x04
                          
 
// k=iictransmit(0x04 );
 
delay1(20);

k=iicstart(0xc4);
 
 k=iictransmit(0x8f);
 
 k= iicrestart(0xc5); 
 
 iicswrcv();
 
// buff[0]=iicreceiveone();
 
 
buff[0]= iicreceivem1();
buff[1]= iicreceivelast();

	*Dist = ((buff[0] << 8) | buff[1]);
	

 delay1(3)  ;
	k=iicstart(0xc4);
 
 k=iictransmit(0x0e);
 
 k= iicrestart(0xc5); 
 
 iicswrcv();
 
 res1=2;
 
 res1=iicreceiveone();
 PORTB=res1 &0x00ff;
 

}

// ********************












void setAlarm1(uint16_t msDelay1)
{
    alarmTime1 = currentTime1 + msDelay1;
    alarmSet1 = 1;
    alarmSignaled1 = 0;
}


void delay1(uint16_t msec)
{
    TC6 = TCNT + 24000; // Set initial time
    setAlarm1(msec);
    while(!alarmSignaled1) {};
}



/*  Interrupt   EMN */

// interrupt(((0x10000-Vtimch7)/2)-1) void TC7_ISR(void){
// the line above is to make it portable between differen
// Freescale processors
// The symbols for each interrupt ( in this case Vtimch7 )'
// are defined in the provided variable definition file
// I am usign a much simpler definition ( vector number) 
// that is easier to understand

interrupt 14 void TC6_ISR(void) {
   
  TC6 =TCNT + 24000;   // interrupt every msec
  TFLG1=TFLG1 | TFLG1_C6F_MASK;
  currentTime1++;
    if (alarmSet1 && currentTime1 == alarmTime1)
    {
        alarmSignaled1 = 1;
        alarmSet1 = 0;
    }
   //PORTB=PORTB+1;        // count   (debugging)
}



void Init_TC6 (void) {
  
_asm SEI;

TSCR1=0x80;
TSCR2=0x00;   // prescaler 1, before 32 = 0x04
TIOS=TIOS | TIOS_IOS6_MASK;
TCTL1=0x40;
TIE=TIE | 0x40;;

 _asm CLI;
 
}


